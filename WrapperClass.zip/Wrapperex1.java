
public class Wrapperex1 {

	public static void main(String[] args) {
		System.out.println("Integer range:");
		System.out.println("Max range :  " + Integer.MAX_VALUE);
		System.out.println("Min RAnge :  "+ Integer.MIN_VALUE);
		System.out.println("Double range:");
		System.out.println("Max range :  " + Double.MAX_VALUE);
		System.out.println("Min RAnge :  "+ Double.MIN_VALUE);
		System.out.println("Long range:");
		System.out.println("Max range :  " + Long.MAX_VALUE);
		System.out.println("Min RAnge :  "+ Long.MIN_VALUE);
		System.out.println("Short range:");
		System.out.println("Max range :  " + Short.MAX_VALUE);
		System.out.println("Min RAnge :  "+ Short.MIN_VALUE);
		System.out.println("Integer range:");
		System.out.println("Max range :  " + Byte.MAX_VALUE);
		System.out.println("Min RAnge :  "+ Byte.MIN_VALUE);
		System.out.println("Float Range");
		System.out.println("Max range :  "+Float.MAX_VALUE);
		System.out.println("Min range :  "+Float.MIN_VALUE);
		

	}

}
