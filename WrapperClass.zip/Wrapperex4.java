class employee implements Cloneable{
	int a;
	String s;
	public Object clone() throws CloneNotSupportedException{
		System.out.println("This is emp method");
		return super.clone();
	}
	
}
public class Wrapperex4 {

	public static void main(String[] args) {
		try {
		employee obj1 = new employee();
		obj1.a = 12;
		obj1.s = "jyoti";
		
		employee obj2 =(employee) obj1.clone();
		obj2.a = 15;
		obj2.s = "nain";
		System.out.println("Original object : a = "+obj1.a +" b = " + obj1.s );
		System.out.println("Clone object : a = "+obj2.a +" b = " + obj2.s );
		}
		catch(CloneNotSupportedException c){
			System.out.println(c);
		}
	}

}
