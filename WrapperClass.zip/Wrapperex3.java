import java.util.Scanner;
public class Wrapperex3 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter an integer number between 1 and 255 : ");
		int i= scan.nextInt();
	System.out.println("Binar representation is as following : ");
		 
	System.out.println(String.format("%8s", Integer.toBinaryString(i)).replace(' ', '0'));
	}

}
