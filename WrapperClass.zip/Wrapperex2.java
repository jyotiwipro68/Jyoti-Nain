
public class Wrapperex2 {

	public static void main(String[] args) {
		int i = Integer.parseInt(args[0]);
				System.out.println("Java Test " + i);
				System.out.println("The Given Number is : "+ i);
				System.out.println("Binary equivalent : "+Integer.toBinaryString(i));
				System.out.println("Octal equivalent : "+Integer.toOctalString(i));
				System.out.println("Hexadecimal equivalent : "+Integer.toHexString(i));

	}

}
