package oops;
import java.util.*;

public class VideoLauncher extends VideoStore{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		
		while(true)
		{
			System.out.println("1.Add\n2.CheckOut\n3.Return\n4.Recieve\n5.List\n6.Exit\n\nEnter Your Choice : " );
			int n=sc.nextInt();
			sc.nextLine();
			switch(n)
			{
				case 1: System.out.print("Enter the Video Name : ");
						String s=sc.nextLine();
						addVideo(s);
						System.out.println("Video "+s+" Added Successfully");
						break;
						
				case 2: System.out.print("Enter the Video Name to CheckOut : ");
						String s1=sc.nextLine();
						doCheckout(s1);
						break;
						
				case 3: System.out.print("Enter the Video Name you want to Return : ");
						String s2=sc.nextLine();
						doReturn(s2);
						break;
						
				case 4: System.out.print("Enter the Video Name you want to Rate : ");
						String s3=sc.nextLine();
						System.out.println("Enter the Rating you want to give : ");
						int rate=sc.nextInt();
						recieveRating(s3,rate);
						break;
						
				case 5: System.out.println("Video Name\tCheckOut Status\tRating");
				for(int i=0;i<store.size();i++)
				{
					System.out.println(store.get(i).getName()+"\t\t"+store.get(i).getCheckout()+"\t"+store.get(i).getRating());
					
				}
				
						break;
						
				case 6: System.out.println("Exiting  .... !! \nThanks for using the Application.");
						System.exit(0);
			}
		}
	}
}
