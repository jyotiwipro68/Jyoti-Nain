package oops;

public class Video {
	String videoName;
	boolean checkout;
	int rating;
	
	public Video(String name)
	{
		this.videoName=name;
		this.checkout=false;
		this.rating=0;
	}
	public String getName()
	{
		return this.videoName;
	}
	void doCheckOut()
	{
		this.checkout=true;
	}
	void  doReturn()
	{
		this.checkout=false;
	}
	void recieveRating(int rating)
	{
		this.rating=rating;
	}
	int getRating()
	{
		return this.rating;
	}
	boolean getCheckout()
	{
		return this.checkout;
	}
}
