package oops;
import java.util.*;

public class VideoStore {
	static ArrayList <Video>store=new ArrayList<Video>();
	
	static void addVideo(String name)
	{
		store.add(new Video(name));
	}
	static void doCheckout(String name)
	{
		int flag=0;
		for(int i=0;i<store.size();i++)
		{
			if((store.get(i).videoName).equals(name))
			{
				if(store.get(i).getCheckout()==false) {
				store.get(i).doCheckOut();
				System.out.println("Video "+name+" Successfully Checked Out");
				flag=1;}
			}
		}
		if(flag==0)
		{
			System.out.println("No Video Found");
		}
	}
	static void doReturn(String name)
	{
		for(int i=0;i<store.size();i++)
		{
			if((store.get(i).videoName).equals(name))
			{
				if(store.get(i).getCheckout()==true) {
				store.get(i).doReturn();
				System.out.println("Video "+name+" Returned Successfully");
			}}
		}
		
	}
	static void recieveRating(String name,int rating)
	{
		for(int i=0;i<store.size();i++)
		{
			if((store.get(i).videoName).equals(name))
			{
				store.get(i).recieveRating(rating);
			}
		}
		System.out.println("Rating  "+rating+" has been mapped to Video "+name);
	}
	void listInventory()
	{
		for(int i=0;i<store.size();i++)
		{
			System.out.println(store.get(i).getName()+"\t\t"+store.get(i).getCheckout()+"\t"+store.get(i).getRating());
		}
	}
}
